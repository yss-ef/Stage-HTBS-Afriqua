<?php
/* Copyright (C) 2005-2012   Regis Houssin   <regis.houssin@inodbox.com>
 *
 * This file is a custom PDF model for Dolibarr Intervention module.
 * It is designed to replicate a specific visual layout, display intervention lines,
 * and automatically calculate header fields from line details.
 */

require_once DOL_DOCUMENT_ROOT.'/core/modules/fichinter/modules_fichinter.php';
require_once DOL_DOCUMENT_ROOT.'/core/lib/company.lib.php';
require_once DOL_DOCUMENT_ROOT.'/core/lib/pdf.lib.php';
require_once DOL_DOCUMENT_ROOT.'/core/lib/date.lib.php';

class pdf_perso extends ModelePDFFicheinter
{
    public $db;
    public $name;
    public $description;
    public $type;
    public $version = 'dolibarr';

    public function __construct($db)
    {
        global $langs, $mysoc;
        $this->db = $db;
        $this->name = 'perso';
        $this->description = "PV Intervention";
        $this->type = 'pdf';
        $formatarray = pdf_getFormat();
        $this->page_largeur = $formatarray['width'];
        $this->page_hauteur = $formatarray['height'];
        $this->format = array($this->page_largeur, $this->page_hauteur);
        $this->marge_gauche = 10;
        $this->marge_droite = 10;
        $this->marge_haute = 10;
        $this->marge_basse = 10;
        $this->emetteur = $mysoc;
    }

    public function write_file($object, $outputlangs, $srctemplatepath = '', $hidedetails = 0, $hidedesc = 0, $hideref = 0)
    {
        global $conf, $langs, $user;

        if (!is_object($outputlangs)) {
            $outputlangs = $langs;
        }
        $outputlangs->loadLangs(array("main", "interventions", "companies", "users"));
        
        // Load extrafields
        $object->fetch_optionals();

        // --- AUTOMATIC CALCULATIONS FROM LINES ---
        $earliest_start_timestamp = null;
        $total_duration_seconds = 0;

        if (!empty($object->lines)) {
            $start_timestamps = array();
            foreach ($object->lines as $line) {
                $total_duration_seconds += $line->duration;
                if (!empty($line->datei)) {
                    $start_timestamps[] = $line->datei;
                }
            }
            if (!empty($start_timestamps)) {
                $earliest_start_timestamp = min($start_timestamps);
            }
        }
        $final_end_timestamp = $earliest_start_timestamp ? $earliest_start_timestamp + $total_duration_seconds : null;
        // --- END OF CALCULATIONS ---

        $pdf = pdf_getInstance($this->format);
        $pdf->SetAutoPageBreak(true, $this->marge_basse);
        $pdf->SetFont(pdf_getPDFFont($outputlangs));
        $pdf->SetMargins($this->marge_gauche, $this->marge_haute, $this->marge_droite);
        $pdf->AddPage();

        $this->_pagehead_perso($pdf, $object, $outputlangs);

        // --- DYNAMIC BOXED TITLE ---
        $pdf->SetY(35);
        $pdf->SetFont('', 'B', 12);
        $pdf->SetFillColor(70, 130, 180); // SteelBlue color
        $pdf->SetTextColor(255, 255, 255);

        // Get value from extrafield "typeintervention"
        $type_intervention_value = (isset($object->array_options['options_typeintervention']) ? $outputlangs->convToOutputCharset($object->array_options['options_typeintervention']) : '');
        
        // Build the title prefix
        $dynamic_title_part = $outputlangs->transnoentities("INTERVENTION");
        if (!empty($type_intervention_value)) {
            $dynamic_title_part .= ' ' . mb_strtoupper($type_intervention_value, 'UTF-8');
        }

        // Assemble the final title with the reference
        $title = $dynamic_title_part . ' : ' . $outputlangs->convToOutputCharset($object->ref);

        $pdf->Cell(0, 10, $title, 0, 1, 'C', true);
        $pdf->SetTextColor(0, 0, 0); // Reset text color
        
        $numero_marche = (isset($object->array_options['options_numeromarche']) ? $outputlangs->convToOutputCharset($object->array_options['options_numeromarche']) : '');
        
        $pdf->Ln(5); // Bottom spacing

        // #################### MODIFIED SECTION START ####################
        // --- NEW DETAILS TABLE (STYLE UPDATED) ---

        // Fetch all required values from extrafields
        $intitule_marche = (isset($object->array_options['options_intitulemarche']) ? $outputlangs->convToOutputCharset($object->array_options['options_intitulemarche']) : '');
        $lieu = (isset($object->array_options['options_lieu']) ? $outputlangs->convToOutputCharset($object->array_options['options_lieu']) : '');
        $intervenant_name = (isset($object->array_options['options_intervenant']) ? $outputlangs->convToOutputCharset($object->array_options['options_intervenant']) : '');
        $trimestre = (isset($object->array_options['options_trimestre']) ? $outputlangs->convToOutputCharset($object->array_options['options_trimestre']) : '');
        
        // Table properties
        $pdf->SetFont('', '', 10);
        $line_height = 8;
        $label_width = 40;
        $value_width = ($this->page_largeur - $this->marge_gauche - $this->marge_droite) / 2 - $label_width;
        
        // --- Row 1: Intitulé du marché & Numéro du marché ---
        $pdf->SetFont('', 'B');
        $pdf->Cell($label_width, $line_height, $outputlangs->transnoentities("Intitulé du marché"), 0, 0, 'L', false);
        $pdf->SetFont('', '');
        $pdf->Cell($value_width, $line_height, $intitule_marche, 0, 0, 'L');
        
        $pdf->SetFont('', 'B');
        $pdf->Cell($label_width, $line_height, $outputlangs->transnoentities("Numéro du marché"), 0, 0, 'L', false);
        $pdf->SetFont('', '');
        $pdf->Cell($value_width, $line_height, $numero_marche, 0, 1, 'L');

        // --- Row 2: Date & Lieu ---
        $pdf->SetFont('', 'B');
        $pdf->Cell($label_width, $line_height, $outputlangs->transnoentities("Date"), 0, 0, 'L', false);
        $pdf->SetFont('', '');
        $pdf->Cell($value_width, $line_height, dol_print_date($earliest_start_timestamp, 'daytext', false, $outputlangs), 0, 0, 'L');

        $pdf->SetFont('', 'B');
        $pdf->Cell($label_width, $line_height, $outputlangs->transnoentities("Lieu"), 0, 0, 'L', false);
        $pdf->SetFont('', '');
        $pdf->Cell($value_width, $line_height, $lieu, 0, 1, 'L');

        // --- Row 3: Heure de début & Heure de fin ---
        $pdf->SetFont('', 'B');
        $pdf->Cell($label_width, $line_height, $outputlangs->transnoentities("Heure de début"), 0, 0, 'L', false);
        $pdf->SetFont('', '');
        $pdf->Cell($value_width, $line_height, ($earliest_start_timestamp ? date('H\hi', $earliest_start_timestamp) : ''), 0, 0, 'L');

        $pdf->SetFont('', 'B');
        $pdf->Cell($label_width, $line_height, $outputlangs->transnoentities("Heure de fin"), 0, 0, 'L', false);
        $pdf->SetFont('', '');
        $pdf->Cell($value_width, $line_height, ($final_end_timestamp ? date('H\hi', $final_end_timestamp) : ''), 0, 1, 'L');

        // --- Row 4: Intervenant & Trimestre ---
        $pdf->SetFont('', 'B');
        $pdf->Cell($label_width, $line_height, $outputlangs->transnoentities("Intervenant"), 0, 0, 'L', false);
        $pdf->SetFont('', '');
        $pdf->Cell($value_width, $line_height, $intervenant_name, 0, 0, 'L');

        $pdf->SetFont('', 'B');
        $pdf->Cell($label_width, $line_height, $outputlangs->transnoentities("Trimestre"), 0, 0, 'L', false);
        $pdf->SetFont('', '');
        $pdf->Cell($value_width, $line_height, $trimestre, 0, 1, 'L');

        // #################### MODIFIED SECTION END ####################
        
        $pdf->SetY($pdf->GetY() + 5);
        
        // --- OBJET & TACHES ---
        $blue_color = array(65, 105, 225); // RoyalBlue
        $pdf->Ln(5);
        $pdf->SetFont('', '', 11);
        $pdf->SetTextColor($blue_color[0], $blue_color[1], $blue_color[2]);
        $pdf->Cell(0, 7, $outputlangs->transnoentities("Objet"), 0, 1, 'L');
        $pdf->SetTextColor(0,0,0);
        $pdf->Line($pdf->GetX(), $pdf->GetY(), $pdf->GetX() + 15, $pdf->GetY());
        $pdf->Ln(2);
        $pdf->SetFont('', '', 10);
        $objet_text = (isset($object->array_options['options_objet']) ? $object->array_options['options_objet'] : '');
        $pdf->MultiCell(0, 5, $outputlangs->convToOutputCharset($objet_text), 0, 'L');
        $pdf->Ln(8);
        $pdf->SetFont('', 'B', 11);
        $pdf->SetTextColor($blue_color[0], $blue_color[1], $blue_color[2]);
        $pdf->Cell(0, 7, $outputlangs->transnoentities("Taches de maintenance effectuées"), 0, 1, 'L');
        $pdf->SetTextColor(0,0,0);
        $pdf->Line($pdf->GetX(), $pdf->GetY(), $pdf->GetX() + 62, $pdf->GetY());
        $pdf->Ln(2);
        if (!empty($object->lines)) {
            foreach ($object->lines as $line) {
                $pdf->SetFont('', 'B', 10);
                $pdf->MultiCell(0, 5, '- '.$outputlangs->convToOutputCharset($line->desc), 0, 'L');
                $pdf->Ln(2);
            }
        }
        
        // --- SIGNATURE AREA & FOOTER ---
        $pdf->SetY(-40);
        $pdf->SetFont('', 'B', 10);
        $pdf->SetTextColor($blue_color[0], $blue_color[1], $blue_color[2]);
        $half_page = ($this->page_largeur - $this->marge_gauche - $this->marge_droite) / 2;
        $pdf->Cell($half_page, 7, $outputlangs->transnoentities("Signature HTBS"), 0, 0, 'L');
        $pdf->Cell($half_page, 7, $outputlangs->transnoentities("Signature client"), 0, 1, 'L');
        
        // --- FILE OUTPUT ---
        $objectref = dol_sanitizeFileName($object->ref);
        $dir = $conf->ficheinter->dir_output . "/" . $objectref;
        if (!file_exists($dir)) dol_mkdir($dir);
        $file = $dir . "/" . $objectref . ".pdf";
        $pdf->Output($file, 'F');
        if (!empty($conf->global->MAIN_UMASK)) @chmod($file, octdec($conf->global->MAIN_UMASK));
        return 1;
    }

    protected function _pagehead_perso(&$pdf, $object, $outputlangs) {
        global $conf;
        $object->fetch_thirdparty();
        if (!empty($this->emetteur->logo)) {
            $mylogo = $conf->mycompany->multidir_output[$this->emetteur->entity] . "/logos/" . $this->emetteur->logo;
            if (is_readable($mylogo)) {
                $height = pdf_getHeightForLogo($mylogo);
                $pdf->Image($mylogo, $this->marge_gauche, $this->marge_haute, 0, $height);
            }
        }
        if (!empty($object->thirdparty->logo_file)) {
            $clientlogo = $conf->thirdparty->multidir_output[$object->thirdparty->entity] . '/' . $object->thirdparty->id . '/logos/' . $object->thirdparty->logo_file;
            if (is_readable($clientlogo)) {
                $height = pdf_getHeightForLogo($clientlogo);
                $width = pdf_getWidthForLogo($clientlogo);
                $pdf->Image($clientlogo, $this->page_largeur - $this->marge_droite - $width, $this->marge_haute, 0, $height);
            }
        }
    }
}

// WORKAROUND: Add helper functions here to make the file self-sufficient
if (!function_exists('pdf_getHeightForLogo')) {
    function pdf_getHeightForLogo($logo, $dpia = 72) {
        $height = 20; $imgsize = dol_getimagesize($logo);
        if ($imgsize) { $height = round($imgsize[1] * 25.4 / $dpia); }
        if ($height > 25) { $height = 25; }
        return $height;
    }
}
if (!function_exists('pdf_getWidthForLogo')) {
    function pdf_getWidthForLogo($logo, $dpia = 72) {
        $width = 0; $imgsize = dol_getimagesize($logo);
        if ($imgsize) {
            $height = round($imgsize[1] * 25.4 / $dpia);
            if ($height > 25) { $ratio = 25 / $height; $width = round($imgsize[0] * 25.4 / $dpia * $ratio); }
        }
        return $width;
    }
}