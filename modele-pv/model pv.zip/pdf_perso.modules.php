<?php
/* Copyright (C) 2005-2012   Regis Houssin   <regis.houssin@inodbox.com>
 *
 * This file is a custom PDF model for Dolibarr Intervention module.
 * It is designed to replicate a specific visual layout, display intervention lines,
 * and automatically calculate header fields from line details.
 */

require_once DOL_DOCUMENT_ROOT.'/core/modules/fichinter/modules_fichinter.php';
require_once DOL_DOCUMENT_ROOT.'/core/lib/company.lib.php';
require_once DOL_DOCUMENT_ROOT.'/core/lib/pdf.lib.php';
require_once DOL_DOCUMENT_ROOT.'/core/lib/date.lib.php';

class pdf_perso extends ModelePDFFicheinter
{
    public $db;
    public $name;
    public $description;
    public $type;
    public $version = 'dolibarr';

    public function __construct($db)
    {
        global $langs, $mysoc;
        $this->db = $db;
        $this->name = 'perso';
        $this->description = "PV Intervention Final (Calcul Automatique)";
        $this->type = 'pdf';
        $formatarray = pdf_getFormat();
        $this->page_largeur = $formatarray['width'];
        $this->page_hauteur = $formatarray['height'];
        $this->format = array($this->page_largeur, $this->page_hauteur);
        $this->marge_gauche = 10;
        $this->marge_droite = 10;
        $this->marge_haute = 10;
        $this->marge_basse = 10;
        $this->emetteur = $mysoc;
    }

    public function write_file($object, $outputlangs, $srctemplatepath = '', $hidedetails = 0, $hidedesc = 0, $hideref = 0)
    {
        global $conf, $langs, $user;

        if (!is_object($outputlangs)) {
            $outputlangs = $langs;
        }
        $outputlangs->loadLangs(array("main", "interventions", "companies", "users"));
        
        // Load extrafields
        $object->fetch_optionals();

        // --- AUTOMATIC CALCULATIONS FROM LINES ---
        $earliest_start_timestamp = null;
        $total_duration_seconds = 0;

        if (!empty($object->lines)) {
            $start_timestamps = array();
            foreach ($object->lines as $line) {
                $total_duration_seconds += $line->duration;
                if (!empty($line->datei)) {
                    $start_timestamps[] = $line->datei;
                }
            }
            if (!empty($start_timestamps)) {
                $earliest_start_timestamp = min($start_timestamps);
            }
        }
        $final_end_timestamp = $earliest_start_timestamp ? $earliest_start_timestamp + $total_duration_seconds : null;
        // --- END OF CALCULATIONS ---

        $pdf = pdf_getInstance($this->format);
        $pdf->SetAutoPageBreak(true, $this->marge_basse);
        $pdf->SetFont(pdf_getPDFFont($outputlangs));
        $pdf->SetMargins($this->marge_gauche, $this->marge_haute, $this->marge_droite);
        $pdf->AddPage();

        $this->_pagehead_perso($pdf, $object, $outputlangs);

        // --- DYNAMIC BOXED TITLE ---
        $pdf->SetY(35);
        $pdf->SetFont('', 'B', 12);
        $pdf->SetFillColor(70, 130, 180); // SteelBlue color
        $pdf->SetTextColor(255, 255, 255);

        // Get value from extrafield "typeintervention"
        // MODIFIED HERE
        $type_intervention_value = (isset($object->array_options['options_typeintervention']) ? $outputlangs->convToOutputCharset($object->array_options['options_typeintervention']) : '');
        
        // Build the title prefix
        $dynamic_title_part = $outputlangs->transnoentities("INTERVENTION");
        if (!empty($type_intervention_value)) {
            $dynamic_title_part .= ' ' . mb_strtoupper($type_intervention_value, 'UTF-8');
        }

        // Assemble the final title with the reference
        $title = $dynamic_title_part . ' : ' . $outputlangs->convToOutputCharset($object->ref);

        $pdf->Cell(0, 10, $title, 0, 1, 'C', true);
        $pdf->SetTextColor(0, 0, 0); // Reset text color
        
        // --- STYLED SUBTITLE FOR "NUMERO DU MARCHE" ---
        $numero_marche = (isset($object->array_options['options_numeromarche']) ? $outputlangs->convToOutputCharset($object->array_options['options_numeromarche']) : '');
        if (!empty($numero_marche)) {
            $blue_color = array(65, 105, 225); // RoyalBlue
            $pdf->SetTextColor($blue_color[0], $blue_color[1], $blue_color[2]);
            $pdf->SetFont('', '', 11);
            $pdf->Ln(2); // Top spacing
            $subtitle = "Numéro du marché".' : ' . $numero_marche;
            $pdf->Cell(0, 6, $subtitle, 0, 1, 'C');
            $pdf->SetTextColor(0, 0, 0); // Reset text color to black
        }
        $pdf->Ln(4); // Bottom spacing

        // --- DETAILS TABLE ---
        $pdf->SetFont('', '', 10);
        $col1_x = $this->marge_gauche;
        $col2_x = $this->marge_gauche + 95;
        $line_height = 6;
        $current_y = $pdf->GetY();
        $blue_color = array(65, 105, 225); // RoyalBlue

        // Column 1
        $pdf->SetXY($col1_x, $current_y);
        $pdf->SetFont('', 'B'); $pdf->SetTextColor($blue_color[0], $blue_color[1], $blue_color[2]); $pdf->Cell(40, $line_height, $outputlangs->transnoentities("Date").' :');
        $pdf->SetFont('', ''); $pdf->SetTextColor(0,0,0); $pdf->Cell(55, $line_height, dol_print_date($earliest_start_timestamp, 'daytext', false, $outputlangs));
        $pdf->Ln($line_height);
        $pdf->SetX($col1_x);
        $pdf->SetFont('', 'B'); $pdf->SetTextColor($blue_color[0], $blue_color[1], $blue_color[2]); $pdf->Cell(40, $line_height, $outputlangs->transnoentities("Heure de début").' :');
        $pdf->SetFont('', ''); $pdf->SetTextColor(0,0,0); $pdf->Cell(55, $line_height, ($earliest_start_timestamp ? date('H\hi', $earliest_start_timestamp) : ''));
        $pdf->Ln($line_height);
        $pdf->SetX($col1_x);
        $intervenant_name = (isset($object->array_options['options_intervenant']) ? $object->array_options['options_intervenant'] : '');
        $pdf->SetFont('', 'B'); $pdf->SetTextColor($blue_color[0], $blue_color[1], $blue_color[2]); $pdf->Cell(40, $line_height, $outputlangs->transnoentities("Intervenant").' :');
        $pdf->SetFont('', ''); $pdf->SetTextColor(0,0,0); $pdf->Cell(55, $line_height, $outputlangs->convToOutputCharset($intervenant_name));

        // Column 2
        $pdf->SetXY($col2_x, $current_y);
        $pdf->SetFont('', 'B'); $pdf->SetTextColor($blue_color[0], $blue_color[1], $blue_color[2]); $pdf->Cell(40, $line_height, $outputlangs->transnoentities("Lieu").' :');
        $pdf->SetFont('', ''); $pdf->SetTextColor(0,0,0); $pdf->Cell(55, $line_height, (isset($object->array_options['options_lieu']) ? $outputlangs->convToOutputCharset($object->array_options['options_lieu']) : ''));
        $pdf->Ln($line_height);
        $pdf->SetX($col2_x);
        $pdf->SetFont('', 'B'); $pdf->SetTextColor($blue_color[0], $blue_color[1], $blue_color[2]); $pdf->Cell(40, $line_height, $outputlangs->transnoentities("Heure de fin").' :');
        $pdf->SetFont('', ''); $pdf->SetTextColor(0,0,0); $pdf->Cell(55, $line_height, ($final_end_timestamp ? date('H\hi', $final_end_timestamp) : ''));
        $pdf->Ln($line_height);
        $pdf->SetX($col2_x);
        

        $pdf->SetTextColor(0,0,0);
        $pdf->SetY($pdf->GetY() + 10);
        
        // --- OBJET & TACHES ---
        $pdf->Ln(5);
        $pdf->SetFont('', 'B', 11);
        $pdf->SetTextColor($blue_color[0], $blue_color[1], $blue_color[2]);
        $pdf->Cell(0, 7, $outputlangs->transnoentities("Objet"), 0, 1, 'L');
        $pdf->SetTextColor(0,0,0);
        $pdf->Line($pdf->GetX(), $pdf->GetY(), $pdf->GetX() + 15, $pdf->GetY());
        $pdf->Ln(2);
        $pdf->SetFont('', '', 10);
        $objet_text = (isset($object->array_options['options_objet']) ? $object->array_options['options_objet'] : '');
        $pdf->MultiCell(0, 5, $outputlangs->convToOutputCharset($objet_text), 0, 'L');
        $pdf->Ln(8);
        $pdf->SetFont('', 'B', 11);
        $pdf->SetTextColor($blue_color[0], $blue_color[1], $blue_color[2]);
        $pdf->Cell(0, 7, $outputlangs->transnoentities("Taches de maintenance effectuées"), 0, 1, 'L');
        $pdf->SetTextColor(0,0,0);
        $pdf->Line($pdf->GetX(), $pdf->GetY(), $pdf->GetX() + 62, $pdf->GetY());
        $pdf->Ln(2);
        if (!empty($object->lines)) {
            foreach ($object->lines as $line) {
                $pdf->SetFont('', 'B', 10);
                $pdf->MultiCell(0, 5, '- '.$outputlangs->convToOutputCharset($line->desc), 0, 'L');
                $pdf->Ln(2);
            }
        }
        
        // --- SIGNATURE AREA & FOOTER ---
        $pdf->SetY(-40);
        $pdf->SetFont('', 'B', 10);
        $pdf->SetTextColor($blue_color[0], $blue_color[1], $blue_color[2]);
        $half_page = ($this->page_largeur - $this->marge_gauche - $this->marge_droite) / 2;
        $pdf->Cell($half_page, 7, $outputlangs->transnoentities("Signature HTBS"), 0, 0, 'L');
        $pdf->Cell($half_page, 7, $outputlangs->transnoentities("Signature client"), 0, 1, 'L');
        
        // --- FILE OUTPUT ---
        $objectref = dol_sanitizeFileName($object->ref);
        $dir = $conf->ficheinter->dir_output . "/" . $objectref;
        if (!file_exists($dir)) dol_mkdir($dir);
        $file = $dir . "/" . $objectref . ".pdf";
        $pdf->Output($file, 'F');
        if (!empty($conf->global->MAIN_UMASK)) @chmod($file, octdec($conf->global->MAIN_UMASK));
        return 1;
    }

    protected function _pagehead_perso(&$pdf, $object, $outputlangs) {
        global $conf;
        $object->fetch_thirdparty();
        if (!empty($this->emetteur->logo)) {
            $mylogo = $conf->mycompany->multidir_output[$this->emetteur->entity] . "/logos/" . $this->emetteur->logo;
            if (is_readable($mylogo)) {
                $height = pdf_getHeightForLogo($mylogo);
                $pdf->Image($mylogo, $this->marge_gauche, $this->marge_haute, 0, $height);
            }
        }
        if (!empty($object->thirdparty->logo_file)) {
            $clientlogo = $conf->thirdparty->multidir_output[$object->thirdparty->entity] . '/' . $object->thirdparty->id . '/logos/' . $object->thirdparty->logo_file;
            if (is_readable($clientlogo)) {
                $height = pdf_getHeightForLogo($clientlogo);
                $width = pdf_getWidthForLogo($clientlogo);
                $pdf->Image($clientlogo, $this->page_largeur - $this->marge_droite - $width, $this->marge_haute, 0, $height);
            }
        }
    }
}

// WORKAROUND: Add helper functions here to make the file self-sufficient
if (!function_exists('pdf_getHeightForLogo')) {
    function pdf_getHeightForLogo($logo, $dpia = 72) {
        $height = 20; $imgsize = dol_getimagesize($logo);
        if ($imgsize) { $height = round($imgsize[1] * 25.4 / $dpia); }
        if ($height > 25) { $height = 25; }
        return $height;
    }
}
if (!function_exists('pdf_getWidthForLogo')) {
    function pdf_getWidthForLogo($logo, $dpia = 72) {
        $width = 0; $imgsize = dol_getimagesize($logo);
        if ($imgsize) {
            $height = round($imgsize[1] * 25.4 / $dpia);
            if ($height > 25) { $ratio = 25 / $height; $width = round($imgsize[0] * 25.4 / $dpia * $ratio); }
        }
        return $width;
    }
}