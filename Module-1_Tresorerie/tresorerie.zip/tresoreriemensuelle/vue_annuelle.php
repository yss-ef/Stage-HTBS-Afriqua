<?php
/**
 * Page de la vue annuelle du module Tableau de Bord de Trésorerie
 *
 * Affiche une synthèse des flux financiers pour chaque mois de l'année sélectionnée.
 */

// --- 1. CHARGEMENT DE L'ENVIRONNEMENT DOLIBARR ---
$res = 0;
if (!$res && file_exists("../../main.inc.php")) { $res = @include "../../main.inc.php"; }
if (!$res && file_exists("../../../main.inc.php")) { $res = @include "../../../main.inc.php"; }
if (!$res) { die("Include of main fails"); }

// --- 2. CHARGEMENT DES CLASSES, LIBRAIRIES ET TRADUCTIONS ---
require_once DOL_DOCUMENT_ROOT.'/fourn/class/fournisseur.facture.class.php';
require_once DOL_DOCUMENT_ROOT.'/compta/facture/class/facture.class.php';

if (!empty($conf->expensereport->enabled)) {
    require_once DOL_DOCUMENT_ROOT.'/expensereport/class/expensereport.class.php';
}
if (!empty($conf->tax->enabled)) {
    require_once DOL_DOCUMENT_ROOT.'/compta/sociales/class/chargesociales.class.php';
}

$langs->loadLangs(array("bills", "companies", "compta", "treasury", "tresoreriemensuelle@tresoreriemensuelle"));

// ==============================================================================
// --- SECTION DES CALCULS PRÉALABLES ---
// ==============================================================================

// --- Définition de l'année à analyser ---
// Récupère l'année depuis l'URL (via le formulaire), sinon utilise l'année en cours.
$year_to_analyze = GETPOST('year', 'int') ? GETPOST('year', 'int') : date('Y');

$annual_data = array();

// --- Boucle principale : on calcule les totaux pour chaque mois de l'année ---
for ($month = 1; $month <= 12; $month++)
{
    // Définition des dates du mois en cours de la boucle
    $date_start_month = dol_mktime(0, 0, 0, $month, 1, $year_to_analyze);
    $date_end_month = dol_mktime(23, 59, 59, $month, date('t', $date_start_month), $year_to_analyze);

    // --- Recopie de la logique de calcul de l'index, mois par mois ---

    // Total Entrées (Réalisé + Prévu)
    $total_a_recevoir_ce_mois = 0;
    $sql = "SELECT SUM(f.total_ttc) as total FROM ".MAIN_DB_PREFIX."facture as f WHERE f.fk_statut = 1 AND f.date_lim_reglement >= '".$db->idate($date_start_month)."' AND f.date_lim_reglement <= '".$db->idate($date_end_month)."'";
    $resql = $db->query($sql);
    if ($resql) { $obj = $db->fetch_object($resql); if ($obj) $total_a_recevoir_ce_mois = (float) $obj->total; }
    $total_clients_regles_ce_mois = 0;
    $sql = "SELECT SUM(pf.amount) as total FROM ".MAIN_DB_PREFIX."paiement_facture as pf JOIN ".MAIN_DB_PREFIX."paiement as p ON pf.fk_paiement = p.rowid JOIN ".MAIN_DB_PREFIX."facture as f ON pf.fk_facture = f.rowid WHERE (CASE WHEN p.datep IS NOT NULL AND p.datep > '1971-01-01' THEN p.datep ELSE f.date_valid END) BETWEEN '".$db->idate($date_start_month)."' AND '".$db->idate($date_end_month)."'";
    $resql = $db->query($sql);
    if ($resql) { $obj = $db->fetch_object($resql); if ($obj) $total_clients_regles_ce_mois = (float) $obj->total; }
    $total_entrees = $total_a_recevoir_ce_mois + $total_clients_regles_ce_mois;

    // TVA sur Entrées (Réalisé + Prévu)
    $tva_prevue_a_encaisser = 0;
    $sql_tva_enc = "SELECT SUM(f.total_tva) as total_tva FROM ".MAIN_DB_PREFIX."facture as f WHERE f.fk_statut = 1 AND f.date_lim_reglement >= '".$db->idate($date_start_month)."' AND f.date_lim_reglement <= '".$db->idate($date_end_month)."'";
    $resql_tva_enc = $db->query($sql_tva_enc);
    if ($resql_tva_enc) { $obj_tva_enc = $db->fetch_object($resql_tva_enc); if ($obj_tva_enc) $tva_prevue_a_encaisser = (float) $obj_tva_enc->total_tva; }
    $tva_realisee_encaissee = 0;
    $sql_tva_realisee = "SELECT SUM(f.total_tva) as total_tva FROM ".MAIN_DB_PREFIX."facture as f WHERE f.rowid IN (SELECT DISTINCT pf.fk_facture FROM ".MAIN_DB_PREFIX."paiement_facture as pf JOIN ".MAIN_DB_PREFIX."paiement as p ON pf.fk_paiement = p.rowid JOIN ".MAIN_DB_PREFIX."facture as f_join ON pf.fk_facture = f_join.rowid WHERE (CASE WHEN p.datep IS NOT NULL AND p.datep > '1971-01-01' THEN p.datep ELSE f_join.date_valid END) BETWEEN '".$db->idate($date_start_month)."' AND '".$db->idate($date_end_month)."')";
    $resql_tva_realisee = $db->query($sql_tva_realisee);
    if ($resql_tva_realisee) { $obj_tva_realisee = $db->fetch_object($resql_tva_realisee); if ($obj_tva_realisee) $tva_realisee_encaissee = (float) $obj_tva_realisee->total_tva; }
    $tva_a_encaisser_total = $tva_prevue_a_encaisser + $tva_realisee_encaissee;

    // Sorties Fournisseurs (Réalisé + Prévu)
    $total_a_payer_fourn_ce_mois = 0;
    $sql = "SELECT SUM(f.total_ttc) as total FROM ".MAIN_DB_PREFIX."facture_fourn as f WHERE f.fk_statut = 1 AND f.date_lim_reglement >= '".$db->idate($date_start_month)."' AND f.date_lim_reglement <= '".$db->idate($date_end_month)."'";
    $resql = $db->query($sql);
    if ($resql) { $obj = $db->fetch_object($resql); if ($obj) $total_a_payer_fourn_ce_mois = (float) $obj->total; }
    $total_fourn_payes_ce_mois = 0;
    $sql = "SELECT SUM(pf.amount) as total FROM ".MAIN_DB_PREFIX."paiementfourn_facturefourn as pf JOIN ".MAIN_DB_PREFIX."paiementfourn as p ON pf.fk_paiementfourn = p.rowid WHERE p.datep >= '".$db->idate($date_start_month)."' AND p.datep <= '".$db->idate($date_end_month)."'";
    $resql = $db->query($sql);
    if ($resql) { $obj = $db->fetch_object($resql); if ($obj) $total_fourn_payes_ce_mois = (float) $obj->total; }
    $total_sorties_fournisseurs = $total_a_payer_fourn_ce_mois + $total_fourn_payes_ce_mois;

    // Charges & Dépenses (Réalisé + Prévu)
    $total_charges_prevu = 0;
    if (!empty($conf->expensereport->enabled)) {
        $sql_ndf = "SELECT SUM(er.total_ttc) as total FROM ".MAIN_DB_PREFIX."expensereport as er WHERE er.fk_statut = 5 AND er.paye = 0";
        $resql_ndf = $db->query($sql_ndf);
        if ($resql_ndf) { $obj_ndf = $db->fetch_object($resql_ndf); if ($obj_ndf) $total_charges_prevu += (float) $obj_ndf->total; }
    }
    if (!empty($conf->tax->enabled)) {
        $sql_charges = "SELECT SUM(cs.amount) as total FROM ".MAIN_DB_PREFIX."chargesociales as cs WHERE cs.paye = 0 AND cs.date_ech >= '".$db->idate($date_start_month)."' AND cs.date_ech <= '".$db->idate($date_end_month)."'";
        $resql_charges = $db->query($sql_charges);
        if ($resql_charges) { $obj_charges = $db->fetch_object($resql_charges); if ($obj_charges) $total_charges_prevu += (float) $obj_charges->total; }
    }
    $total_charges_realise = 0;
    if (!empty($conf->tax->enabled)) {
        $sql_charges_payees = "SELECT SUM(cs.amount) as total FROM ".MAIN_DB_PREFIX."chargesociales as cs WHERE cs.paye = 1 AND cs.date_creation >= '".$db->idate($date_start_month)."' AND cs.date_creation <= '".$db->idate($date_end_month)."'";
        $resql_charges_payees = $db->query($sql_charges_payees);
        if ($resql_charges_payees) { $obj_cp = $db->fetch_object($resql_charges_payees); if ($obj_cp) $total_charges_realise += (float) $obj_cp->total; }
    }
    $total_sorties_charges = $total_charges_prevu + $total_charges_realise;

    // TVA à Décaisser
    $tva_collectee = 0;
    $sql_tva_c = "SELECT SUM(f.total_tva) as total_tva FROM ".MAIN_DB_PREFIX."facture as f WHERE f.fk_statut > 0 AND f.datef >= '".$db->idate($date_start_month)."' AND f.datef <= '".$db->idate($date_end_month)."'";
    $resql_tva_c = $db->query($sql_tva_c);
    if ($resql_tva_c) { $obj_tva_c = $db->fetch_object($resql_tva_c); if ($obj_tva_c) $tva_collectee = (float) $obj_tva_c->total_tva; }
    $tva_deductible = 0;
    $sql_tva_d = "SELECT SUM(ff.tva) as total_tva FROM ".MAIN_DB_PREFIX."facture_fourn as ff WHERE ff.fk_statut > 0 AND ff.datef >= '".$db->idate($date_start_month)."' AND ff.datef <= '".$db->idate($date_end_month)."'";
    $resql_tva_d = $db->query($sql_tva_d);
    if ($resql_tva_d) { $obj_tva_d = $db->fetch_object($resql_tva_d); if ($obj_tva_d) $tva_deductible = (float) $obj_tva_d->total_tva; }
    $tva_a_decaisser = $tva_collectee - $tva_deductible;

    // Synthèse Nette
    $synthese_nette = $total_entrees - $total_sorties_fournisseurs - $total_sorties_charges - ($tva_a_decaisser > 0 ? $tva_a_decaisser : 0);

    // Stockage des données du mois dans un tableau
    $annual_data[$month] = array(
        'entrees' => $total_entrees,
        'tva_entrees' => $tva_a_encaisser_total,
        'sorties_fourn' => $total_sorties_fournisseurs,
        'sorties_charges' => $total_sorties_charges,
        'tva_decaisser' => $tva_a_decaisser,
        'flux_net' => $synthese_nette
    );
}

// --- Calcul des totaux annuels ---
$grand_total_entrees = 0; $grand_total_tva_entrees = 0; $grand_total_sorties_fourn = 0;
$grand_total_sorties_charges = 0; $grand_total_tva_decaisser = 0; $grand_total_flux_net = 0;
foreach ($annual_data as $month_data) {
    $grand_total_entrees += $month_data['entrees'];
    $grand_total_tva_entrees += $month_data['tva_entrees'];
    $grand_total_sorties_fourn += $month_data['sorties_fourn'];
    $grand_total_sorties_charges += $month_data['sorties_charges'];
    $grand_total_tva_decaisser += $month_data['tva_decaisser'];
    $grand_total_flux_net += $month_data['flux_net'];
}

// ==============================================================================
// --- AFFICHAGE DE LA PAGE ---
// ==============================================================================
llxHeader("", "Vue Annuelle de Trésorerie");
print load_fiche_titre("Vue Annuelle de Trésorerie pour " . $year_to_analyze, '', 'fas fa-calendar-alt');

// --- NOUVEAU : Formulaire de sélection de l'année ---
print '<form method="GET" action="'.$_SERVER["PHP_SELF"].'">';
print '<div class="center" style="margin-bottom: 20px;">';
print 'Afficher l\'année : ';
print '<input type="number" name="year" value="'.$year_to_analyze.'" size="4" maxlength="4" style="min-width: 60px;">';
print '<input type="submit" class="button" value="Afficher">';
print '</div>';
print '</form>';
// --- FIN NOUVEAU ---

// --- Affichage du Tableau Annuel ---
print '<table class="noborder centpercent">';
print '<tr class="liste_titre">';
print '<th>Mois</th>';
print '<th class="right">Total Entrées (TTC)</th>';
print '<th class="right">TVA sur Entrées</th>';
print '<th class="right">Sorties Fournisseurs</th>';
print '<th class="right">Charges & Dépenses</th>';
print '<th class="right">TVA à Décaisser</th>';
print '<th class="right">Flux Net Mensuel</th>';
print '</tr>';

// Boucle d'affichage
for ($m = 1; $m <= 12; $m++) {
    $month_ts = dol_mktime(0, 0, 0, $m, 1, $year_to_analyze);
    $month_data = $annual_data[$m];
    $flux_color = ($month_data['flux_net'] >= 0) ? 'green' : 'red';

    print '<tr class="oddeven">';
    print '<td>'.dol_print_date($month_ts, "%B").'</td>';
    print '<td class="right" style="color:green;">'.price($month_data['entrees']).'</td>';
    print '<td class="right" style="color:#27AE60;">'.price($month_data['tva_entrees']).'</td>';
    print '<td class="right" style="color:red;">'.price($month_data['sorties_fourn']).'</td>';
    print '<td class="right" style="color:#E67E22;">'.price($month_data['sorties_charges']).'</td>';
    print '<td class="right" style="color:'.($month_data['tva_decaisser'] >= 0 ? 'red' : 'green').';">'.price($month_data['tva_decaisser']).'</td>';
    print '<td class="right" style="font-weight:bold; color:'.$flux_color.';">'.price($month_data['flux_net']).'</td>';
    print '</tr>';
}

// Ligne des totaux
$grand_flux_color = ($grand_total_flux_net >= 0) ? 'green' : 'red';
print '<tr class="liste_total" style="font-size: 1.1em;">';
print '<td><b>TOTAL ANNUEL</b></td>';
print '<td class="right"><b>'.price($grand_total_entrees).'</b></td>';
print '<td class="right"><b>'.price($grand_total_tva_entrees).'</b></td>';
print '<td class="right"><b>'.price($grand_total_sorties_fourn).'</b></td>';
print '<td class="right"><b>'.price($grand_total_sorties_charges).'</b></td>';
print '<td class="right"><b>'.price($grand_total_tva_decaisser).'</b></td>';
print '<td class="right" style="font-weight:bold; color:'.$grand_flux_color.';"><b>'.price($grand_total_flux_net).'</b></td>';
print '</tr>';

print '</table>';

llxFooter();
$db->close();
?>