<?php
/**
 * Page d'accueil du module Tableau de Bord de Trésorerie Mensuelle
 *
 * Affiche une synthèse des flux financiers (prévus et réalisés) pour le mois en cours,
 * ainsi que des listes détaillées pour le suivi des retards, des prévisions et de l'activité.
 *
 * @author      VotreNom <votre.email@example.com>
 * @version     2.2
 */

// --- 1. CHARGEMENT DE L'ENVIRONNEMENT DOLIBARR ---
$res = 0;
if (!$res && file_exists("../../main.inc.php")) { $res = @include "../../main.inc.php"; }
if (!$res && file_exists("../../../main.inc.php")) { $res = @include "../../../main.inc.php"; }
if (!$res) { die("Include of main fails"); }

// --- 2. CHARGEMENT DES CLASSES, LIBRAIRIES ET TRADUCTIONS ---
require_once DOL_DOCUMENT_ROOT.'/fourn/class/fournisseur.facture.class.php';
require_once DOL_DOCUMENT_ROOT.'/compta/facture/class/facture.class.php';

if (!empty($conf->expensereport->enabled)) {
    require_once DOL_DOCUMENT_ROOT.'/expensereport/class/expensereport.class.php';
}
if (!empty($conf->tax->enabled)) {
    require_once DOL_DOCUMENT_ROOT.'/compta/sociales/class/chargesociales.class.php';
}

$langs->loadLangs(array("bills", "companies", "compta", "treasury", "tresoreriemensuelle@tresoreriemensuelle"));

// ==============================================================================
// --- SECTION DES CALCULS PRÉALABLES ---
// ==============================================================================

// --- Définition des dates du mois en cours ---
$now_ts = dol_now();
$date_start_month = dol_mktime(0, 0, 0, date('m', $now_ts), 1, date('Y', $now_ts));
$date_end_month = dol_mktime(23, 59, 59, date('m', $now_ts), date('t', $now_ts), date('Y', $now_ts));

// ==============================================================================
// --- CALCULS POUR LE TABLEAU DE SYNTHÈSE (MOIS EN COURS) ---
// ==============================================================================

// --- COLONNE 1 : Total des Entrées (Réalisé + Prévu) ---
$total_a_recevoir_ce_mois = 0;
$sql = "SELECT SUM(f.total_ttc) as total FROM ".MAIN_DB_PREFIX."facture as f WHERE f.fk_statut = 1 AND f.date_lim_reglement >= '".$db->idate($date_start_month)."' AND f.date_lim_reglement <= '".$db->idate($date_end_month)."'";
$resql = $db->query($sql);
if ($resql) { $obj = $db->fetch_object($resql); if ($obj) $total_a_recevoir_ce_mois = (float) $obj->total; }

$total_clients_regles_ce_mois = 0;
$sql = "SELECT SUM(pf.amount) as total
        FROM ".MAIN_DB_PREFIX."paiement_facture as pf
        JOIN ".MAIN_DB_PREFIX."paiement as p ON pf.fk_paiement = p.rowid
        JOIN ".MAIN_DB_PREFIX."facture as f ON pf.fk_facture = f.rowid
        WHERE (CASE
                WHEN p.datep IS NOT NULL AND p.datep > '1971-01-01' THEN p.datep
                ELSE f.date_valid
            END)
            BETWEEN '".$db->idate($date_start_month)."' AND '".$db->idate($date_end_month)."'";
$resql = $db->query($sql);
if ($resql) { $obj = $db->fetch_object($resql); if ($obj) $total_clients_regles_ce_mois = (float) $obj->total; }
$total_entrees = $total_a_recevoir_ce_mois + $total_clients_regles_ce_mois;


// --- COLONNE 3 : Sorties Fournisseurs (Réalisé + Prévu) ---
$total_a_payer_fourn_ce_mois = 0;
$sql = "SELECT SUM(f.total_ttc) as total FROM ".MAIN_DB_PREFIX."facture_fourn as f WHERE f.fk_statut = 1 AND f.date_lim_reglement >= '".$db->idate($date_start_month)."' AND f.date_lim_reglement <= '".$db->idate($date_end_month)."'";
$resql = $db->query($sql);
if ($resql) { $obj = $db->fetch_object($resql); if ($obj) $total_a_payer_fourn_ce_mois = (float) $obj->total; }

$total_fourn_payes_ce_mois = 0;
$sql = "SELECT SUM(pf.amount) as total FROM ".MAIN_DB_PREFIX."paiementfourn_facturefourn as pf JOIN ".MAIN_DB_PREFIX."paiementfourn as p ON pf.fk_paiementfourn = p.rowid WHERE p.datep >= '".$db->idate($date_start_month)."' AND p.datep <= '".$db->idate($date_end_month)."'";
$resql = $db->query($sql);
if ($resql) { $obj = $db->fetch_object($resql); if ($obj) $total_fourn_payes_ce_mois = (float) $obj->total; }
$total_sorties_fournisseurs = $total_a_payer_fourn_ce_mois + $total_fourn_payes_ce_mois;


// --- CALCULS POUR LE MOIS PRÉCÉDENT (POUR COMPARAISON) ---
$prev_month_ts = strtotime('-1 month', $now_ts);
$date_start_prev_month = dol_mktime(0, 0, 0, date('m', $prev_month_ts), 1, date('Y', $prev_month_ts));
$date_end_prev_month = dol_mktime(23, 59, 59, date('m', $prev_month_ts), date('t', $prev_month_ts), date('Y', $prev_month_ts));

// Total Entrées du mois précédent
$total_a_recevoir_prev_mois = 0;
$sql_prev_ent_1 = "SELECT SUM(f.total_ttc) as total FROM ".MAIN_DB_PREFIX."facture as f WHERE f.fk_statut = 1 AND f.date_lim_reglement >= '".$db->idate($date_start_prev_month)."' AND f.date_lim_reglement <= '".$db->idate($date_end_prev_month)."'";
$resql = $db->query($sql_prev_ent_1);
if ($resql) { $obj = $db->fetch_object($resql); if ($obj) $total_a_recevoir_prev_mois = (float) $obj->total; }
$total_clients_regles_prev_mois = 0;
$sql_prev_ent_2 = "SELECT SUM(pf.amount) as total FROM ".MAIN_DB_PREFIX."paiement_facture as pf JOIN ".MAIN_DB_PREFIX."paiement as p ON pf.fk_paiement = p.rowid JOIN ".MAIN_DB_PREFIX."facture as f ON pf.fk_facture = f.rowid WHERE (CASE WHEN p.datep IS NOT NULL AND p.datep > '1971-01-01' THEN p.datep ELSE f.date_valid END) BETWEEN '".$db->idate($date_start_prev_month)."' AND '".$db->idate($date_end_prev_month)."'";
$resql = $db->query($sql_prev_ent_2);
if ($resql) { $obj = $db->fetch_object($resql); if ($obj) $total_clients_regles_prev_mois = (float) $obj->total; }
$total_entrees_prev_month = $total_a_recevoir_prev_mois + $total_clients_regles_prev_mois;

// Sorties Fournisseurs du mois précédent
$total_a_payer_fourn_prev_mois = 0;
$sql_prev_sor_1 = "SELECT SUM(f.total_ttc) as total FROM ".MAIN_DB_PREFIX."facture_fourn as f WHERE f.fk_statut = 1 AND f.date_lim_reglement >= '".$db->idate($date_start_prev_month)."' AND f.date_lim_reglement <= '".$db->idate($date_end_prev_month)."'";
$resql = $db->query($sql_prev_sor_1);
if ($resql) { $obj = $db->fetch_object($resql); if ($obj) $total_a_payer_fourn_prev_mois = (float) $obj->total; }
$total_fourn_payes_prev_mois = 0;
$sql_prev_sor_2 = "SELECT SUM(pf.amount) as total FROM ".MAIN_DB_PREFIX."paiementfourn_facturefourn as pf JOIN ".MAIN_DB_PREFIX."paiementfourn as p ON pf.fk_paiementfourn = p.rowid WHERE p.datep >= '".$db->idate($date_start_prev_month)."' AND p.datep <= '".$db->idate($date_end_prev_month)."'";
$resql = $db->query($sql_prev_sor_2);
if ($resql) { $obj = $db->fetch_object($resql); if ($obj) $total_fourn_payes_prev_mois = (float) $obj->total; }
$total_sorties_fournisseurs_prev_month = $total_a_payer_fourn_prev_mois + $total_fourn_payes_prev_mois;

// ### MODIFIÉ : Génération des flèches de tendance avec des icônes ###
$arrow_entrees = '';
if ($total_entrees > $total_entrees_prev_month) $arrow_entrees = img_picto('', 'fa-arrow-up', 'style="color: green;"');
elseif ($total_entrees < $total_entrees_prev_month) $arrow_entrees = img_picto('', 'fa-arrow-down', 'style="color: red;"');
else $arrow_entrees = img_picto('', 'fa-minus', 'style="color: orange;"');

$arrow_sorties = '';
if ($total_sorties_fournisseurs > $total_sorties_fournisseurs_prev_month) $arrow_sorties = img_picto('', 'fa-arrow-up', 'style="color: red;"');      // Hausse des sorties = Négatif
elseif ($total_sorties_fournisseurs < $total_sorties_fournisseurs_prev_month) $arrow_sorties = img_picto('', 'fa-arrow-down', 'style="color: green;"');  // Baisse des sorties = Positif
else $arrow_sorties = img_picto('', 'fa-minus', 'style="color: orange;"');
// ### FIN MODIFICATION ###


// --- COLONNE 2 : TVA sur Entrées (Réalisé + Prévu) ---
$tva_prevue_a_encaisser = 0;
$sql_tva_enc = "SELECT SUM(f.total_tva) as total_tva FROM ".MAIN_DB_PREFIX."facture as f WHERE f.fk_statut = 1 AND f.date_lim_reglement >= '".$db->idate($date_start_month)."' AND f.date_lim_reglement <= '".$db->idate($date_end_month)."'";
$resql_tva_enc = $db->query($sql_tva_enc);
if ($resql_tva_enc) { $obj_tva_enc = $db->fetch_object($resql_tva_enc); if ($obj_tva_enc) $tva_prevue_a_encaisser = (float) $obj_tva_enc->total_tva; }

$tva_realisee_encaissee = 0;
$sql_tva_realisee = "SELECT SUM(f.total_tva) as total_tva FROM ".MAIN_DB_PREFIX."facture as f
    WHERE f.rowid IN (
        SELECT DISTINCT pf.fk_facture
        FROM ".MAIN_DB_PREFIX."paiement_facture as pf
        JOIN ".MAIN_DB_PREFIX."paiement as p ON pf.fk_paiement = p.rowid
        JOIN ".MAIN_DB_PREFIX."facture as f_join ON pf.fk_facture = f_join.rowid
        WHERE (CASE
            WHEN p.datep IS NOT NULL AND p.datep > '1971-01-01' THEN p.datep
            ELSE f_join.date_valid
        END)
        BETWEEN '".$db->idate($date_start_month)."' AND '".$db->idate($date_end_month)."'
    )";
$resql_tva_realisee = $db->query($sql_tva_realisee);
if ($resql_tva_realisee) { $obj_tva_realisee = $db->fetch_object($resql_tva_realisee); if ($obj_tva_realisee) $tva_realisee_encaissee = (float) $obj_tva_realisee->total_tva; }
$tva_a_encaisser_total = $tva_prevue_a_encaisser + $tva_realisee_encaissee;


// --- COLONNE 4 : TVA sur Sorties Fournisseurs (Réalisé + Prévu) ---
$tva_prevue_a_payer_fourn = 0;
$sql_tva_fourn_prevu = "SELECT SUM(f.total_tva) as total_tva
                        FROM ".MAIN_DB_PREFIX."facture_fourn as f
                        WHERE f.fk_statut = 1
                        AND f.date_lim_reglement >= '".$db->idate($date_start_month)."'
                        AND f.date_lim_reglement <= '".$db->idate($date_end_month)."'";
$resql_tva_fourn_prevu = $db->query($sql_tva_fourn_prevu);
if ($resql_tva_fourn_prevu) { $obj = $db->fetch_object($resql_tva_fourn_prevu); if ($obj) $tva_prevue_a_payer_fourn = (float) $obj->total_tva; }

$tva_realisee_payee_fourn = 0;
$sql_tva_fourn_realise = "SELECT SUM(f.total_tva) as total_tva FROM ".MAIN_DB_PREFIX."facture_fourn as f
    WHERE f.rowid IN (
        SELECT DISTINCT pf.fk_facturefourn
        FROM ".MAIN_DB_PREFIX."paiementfourn_facturefourn as pf
        JOIN ".MAIN_DB_PREFIX."paiementfourn as p ON pf.fk_paiementfourn = p.rowid
        WHERE p.datep BETWEEN '".$db->idate($date_start_month)."' AND '".$db->idate($date_end_month)."'
    )";
$resql_tva_fourn_realise = $db->query($sql_tva_fourn_realise);
if ($resql_tva_fourn_realise) { $obj = $db->fetch_object($resql_tva_fourn_realise); if ($obj) $tva_realisee_payee_fourn = (float) $obj->total_tva; }
$total_tva_sorties_fournisseurs = $tva_prevue_a_payer_fourn + $tva_realisee_payee_fourn;


// --- COLONNE 5 : Charges & Dépenses (Réalisé + Prévu) ---
$total_charges_prevu = 0;
if (!empty($conf->expensereport->enabled)) {
    $sql_ndf = "SELECT SUM(er.total_ttc) as total FROM ".MAIN_DB_PREFIX."expensereport as er WHERE er.fk_statut = 5 AND er.paye = 0";
    $resql_ndf = $db->query($sql_ndf);
    if ($resql_ndf) { $obj_ndf = $db->fetch_object($resql_ndf); if ($obj_ndf) $total_charges_prevu += (float) $obj_ndf->total; }
}
if (!empty($conf->tax->enabled)) {
    $sql_charges = "SELECT SUM(cs.amount) as total FROM ".MAIN_DB_PREFIX."chargesociales as cs WHERE cs.paye = 0 AND cs.date_ech >= '".$db->idate($date_start_month)."' AND cs.date_ech <= '".$db->idate($date_end_month)."'";
    $resql_charges = $db->query($sql_charges);
    if ($resql_charges) { $obj_charges = $db->fetch_object($resql_charges); if ($obj_charges) $total_charges_prevu += (float) $obj_charges->total; }
}

$total_charges_realise = 0;
if (!empty($conf->tax->enabled)) {
    $sql_charges_payees = "SELECT SUM(cs.amount) as total FROM ".MAIN_DB_PREFIX."chargesociales as cs WHERE cs.paye = 1 AND cs.date_creation >= '".$db->idate($date_start_month)."' AND cs.date_creation <= '".$db->idate($date_end_month)."'";
    $resql_charges_payees = $db->query($sql_charges_payees);
    if ($resql_charges_payees) { $obj_cp = $db->fetch_object($resql_charges_payees); if ($obj_cp) $total_charges_realise += (float) $obj_cp->total; }
}
$total_sorties_charges = $total_charges_prevu + $total_charges_realise;


// --- COLONNE 6 : Synthèse Nette du Mois ---
$synthese_nette = $total_entrees - $total_sorties_fournisseurs - $total_sorties_charges;
$color = ($synthese_nette >= 0) ? 'green' : 'red';


// --- Données pour le graphique d'activité commerciale (basé sur la date de facturation) ---
$weeks_labels = array(); $data_fournisseurs_semaine = array(); $data_clients_semaine = array(); $days_in_month = date('t', $now_ts); $num_weeks = ceil($days_in_month / 7);
for ($week = 1; $week <= $num_weeks; $week++) {
    $weeks_labels[] = "Semaine " . $week;
    $day_start = (($week - 1) * 7) + 1; $day_end = min($week * 7, $days_in_month);
    $date_start_week = dol_mktime(0, 0, 0, date('m', $now_ts), $day_start, date('Y', $now_ts)); $date_end_week = dol_mktime(23, 59, 59, date('m', $now_ts), $day_end, date('Y', $now_ts));
    $sql_fourn = "SELECT SUM(f.total_ttc) as total FROM ".MAIN_DB_PREFIX."facture_fourn as f WHERE f.fk_statut IN (1, 2) AND f.datef >= '".$db->idate($date_start_week)."' AND f.datef <= '".$db->idate($date_end_week)."'";
    $resql_fourn = $db->query($sql_fourn); $total_fourn_week = 0;
    if ($resql_fourn) { $obj = $db->fetch_object($resql_fourn); if ($obj && $obj->total !== null) $total_fourn_week = $obj->total; }
    $data_fournisseurs_semaine[] = (float) $total_fourn_week;
    $sql_cli = "SELECT SUM(f.total_ttc) as total FROM ".MAIN_DB_PREFIX."facture as f WHERE f.fk_statut IN (1, 2) AND f.datef >= '".$db->idate($date_start_week)."' AND f.datef <= '".$db->idate($date_end_week)."'";
    $resql_cli = $db->query($sql_cli); $total_cli_week = 0;
    if ($resql_cli) { $obj = $db->fetch_object($resql_cli); if ($obj && $obj->total !== null) $total_cli_week = $obj->total; }
    $data_clients_semaine[] = (float) $total_cli_week;
}

// ==============================================================================
// --- AFFICHAGE DE LA PAGE ---
// ==============================================================================
llxHeader("", "Tableau de Bord Trésorerie");
print load_fiche_titre("Tableau de Bord de Trésorerie pour " . dol_print_date($now_ts, "%B %Y"), '', 'fas fa-chart-line');

// --- Affichage du Tableau de Synthèse ---
print '<br>';
print '<table class="noborder centpercent">';
print '<tr class="liste_titre">';
print '<th class="center">Total Entrées</th>';
print '<th class="center">TVA sur Entrées</th>';
print '<th class="center">Sorties Fournisseurs</th>';
print '<th class="center">TVA sur Sorties Fournisseurs</th>';
print '<th class="center">Charges & Dépenses</th>';
print '<th class="center">Synthèse Nette du Mois</th>';
print '</tr>';
print '<tr style="font-size: 1.5em; text-align: center;">';
print '<td style="color: green;">' . price($total_entrees) . ' ' . $arrow_entrees . '</td>';
print '<td style="color: #27AE60;">' . price($tva_a_encaisser_total) . '</td>';
print '<td style="color: red;">' . price($total_sorties_fournisseurs) . ' ' . $arrow_sorties . '</td>';
print '<td style="color: #E74C3C;">' . price($total_tva_sorties_fournisseurs) . '</td>';
print '<td style="color: #E67E22;">' . price($total_sorties_charges) . '</td>';
print '<td style="font-weight: bold; color: ' . $color . ';">' . price($synthese_nette) . '</td>';
print '</tr>';
print '</table>';
print '<br>';

?>
<div class="fichecenter">
    <div class="fichehalfleft">
        <div style="width: 100%; max-width: 400px; margin: auto; padding-bottom: 30px;">
            <h3 style="text-align: center;">Synthèse des Flux du Mois</h3>
            <canvas id="cashflowBarChart"></canvas>
        </div>
    </div>
    <div class="fichehalfright">
        <div style="width: 100%; max-width: 500px; margin: auto; padding-bottom: 30px;">
            <h3 style="text-align: center;">Activité Commerciale Hebdomadaire</h3>
            <canvas id="weeklyActivityChart"></canvas>
        </div>
    </div>
</div>

<script>
$(document).ready(function() {
    var ctxBar = document.getElementById('cashflowBarChart').getContext('2d');
    new Chart(ctxBar, {
        type: 'bar',
        data: {
            labels: ['Flux de Trésorerie du Mois'],
            datasets: [
                {
                    label: 'Total Entrées',
                    data: [<?php echo $total_entrees; ?>],
                    backgroundColor: 'rgba(75, 192, 192, 0.7)'
                },
                {
                    label: 'Sorties Fournisseurs',
                    data: [<?php echo $total_sorties_fournisseurs; ?>],
                    backgroundColor: 'rgba(255, 99, 132, 0.7)',
                    stack: 'Sorties'
                },
                {
                    label: 'Charges & Dépenses',
                    data: [<?php echo $total_sorties_charges; ?>],
                    backgroundColor: 'rgba(230, 126, 34, 0.7)',
                    stack: 'Sorties'
                }
            ]
        },
        options: {
            responsive: true,
            plugins: { legend: { position: 'top' } },
            scales: { x: { stacked: true }, y: { beginAtZero: true, stacked: true } }
        }
    });

    var weeks_labels = <?php echo json_encode($weeks_labels); ?>;
    var data_clients_semaine = <?php echo json_encode($data_clients_semaine); ?>;
    var data_fournisseurs_semaine = <?php echo json_encode($data_fournisseurs_semaine); ?>;
    var ctxWeekly = document.getElementById('weeklyActivityChart').getContext('2d');
    new Chart(ctxWeekly, {
        type: 'bar',
        data: {
            labels: weeks_labels,
            datasets: [
                {
                    label: 'Factures Clients',
                    data: data_clients_semaine,
                    backgroundColor: 'rgba(75, 192, 192, 0.7)',
                },
                {
                    label: 'Factures Fournisseurs',
                    data: data_fournisseurs_semaine,
                    backgroundColor: 'rgba(255, 99, 132, 0.7)',
                }
            ]
        },
        options: {
            responsive: true,
            plugins: { legend: { position: 'top' } },
            scales: { y: { beginAtZero: true } }
        }
    });
});
</script>

<?php
// --- Instanciation unique des objets pour la performance ---
$facture_client_static = new Facture($db);
$facture_fourn_static = new FactureFournisseur($db);
if (!empty($conf->expensereport->enabled)) $expensereport_static = new ExpenseReport($db);
if (!empty($conf->tax->enabled)) $charge_static = new ChargeSociales($db);

// ==============================================================================
// --- SECTION "SUIVI DES RETARDS" (Actions Urgentes) ---
// ==============================================================================
print '<br><br>';
print_barre_liste('Encours Clients en Retard', 0, $_SERVER["PHP_SELF"]);
echo '<table class="noborder centpercent">';
echo '<tr class="liste_titre"><td>Réf. Facture</td><td>Client</td><td class="center">Date Limite</td><td class="center">Jours de Retard</td><td class="right">Montant Dû</td></tr>';
$sql_clients_retard = "SELECT f.rowid, f.ref, f.total_ttc, f.date_lim_reglement, s.nom as societe_nom
                       FROM ".MAIN_DB_PREFIX."facture as f LEFT JOIN ".MAIN_DB_PREFIX."societe as s ON f.fk_soc = s.rowid
                       WHERE f.fk_statut = 1 AND f.date_lim_reglement < '".$db->idate($date_start_month)."' ORDER BY f.date_lim_reglement ASC";
$resql_clients_retard = $db->query($sql_clients_retard);
if ($resql_clients_retard && $db->num_rows($resql_clients_retard) > 0) {
    $total_clients_retard = 0;
    while ($obj = $db->fetch_object($resql_clients_retard)) {
        $facture_client_static->id = $obj->rowid;
        $facture_client_static->ref = $obj->ref;
        $total_clients_retard += $obj->total_ttc;
        $date_lim = $db->jdate($obj->date_lim_reglement);
        $jours_retard = round(($now_ts - $date_lim) / (60 * 60 * 24));
        echo '<tr class="oddeven"><td>'.$facture_client_static->getNomUrl(1).'</td><td>'.$obj->societe_nom.'</td><td class="center">'.dol_print_date($date_lim, 'day').'</td><td class="center" style="color:red; font-weight:bold;">'.$jours_retard.'</td><td class="right">'.price($obj->total_ttc).'</td></tr>';
    }
    echo '<tr class="liste_total"><td colspan="4" class="right"><b>Total des retards clients :</b></td><td class="right"><b>'.price($total_clients_retard).'</b></td></tr>';
} else {
    echo '<tr><td colspan="5" class="opacitymedium">Aucune facture client en retard.</td></tr>';
}
echo '</table>';

print '<br>';
print_barre_liste('Dettes Fournisseurs en Retard', 0, $_SERVER["PHP_SELF"]);
echo '<table class="noborder centpercent">';
echo '<tr class="liste_titre"><td>Réf. Fournisseur</td><td>Fournisseur</td><td class="center">Date Limite</td><td class="center">Jours de Retard</td><td class="right">Montant Dû</td></tr>';
$sql_fourn_retard = "SELECT f.rowid, f.ref_supplier, f.total_ttc, f.date_lim_reglement, s.nom as societe_nom
                     FROM ".MAIN_DB_PREFIX."facture_fourn as f LEFT JOIN ".MAIN_DB_PREFIX."societe as s ON f.fk_soc = s.rowid
                     WHERE f.fk_statut = 1 AND f.date_lim_reglement < '".$db->idate($date_start_month)."' ORDER BY f.date_lim_reglement ASC";
$resql_fourn_retard = $db->query($sql_fourn_retard);
if ($resql_fourn_retard && $db->num_rows($resql_fourn_retard) > 0) {
    $total_fourn_retard = 0;
    while ($obj = $db->fetch_object($resql_fourn_retard)) {
        $facture_fourn_static->id = $obj->rowid;
        $facture_fourn_static->ref_supplier = $obj->ref_supplier;
        $total_fourn_retard += $obj->total_ttc;
        $date_lim = $db->jdate($obj->date_lim_reglement);
        $jours_retard = round(($now_ts - $date_lim) / (60 * 60 * 24));
        echo '<tr class="oddeven"><td>'.$facture_fourn_static->getNomUrl(1).'</td><td>'.$obj->societe_nom.'</td><td class="center">'.dol_print_date($date_lim, 'day').'</td><td class="center" style="color:red; font-weight:bold;">'.$jours_retard.'</td><td class="right">'.price($obj->total_ttc).'</td></tr>';
    }
    echo '<tr class="liste_total"><td colspan="4" class="right"><b>Total des retards fournisseurs :</b></td><td class="right"><b>'.price($total_fourn_retard).'</b></td></tr>';
} else {
    echo '<tr><td colspan="5" class="opacitymedium">Aucune facture fournisseur en retard.</td></tr>';
}
echo '</table>';


// ==============================================================================
// --- SECTION "PRÉVISIONNEL DU MOIS EN COURS" ---
// ==============================================================================
print '<br><br>';
print_barre_liste('Factures clients à encaisser ce mois-ci', 0, $_SERVER["PHP_SELF"]);
echo '<table class="noborder centpercent">';
echo '<tr class="liste_titre"><td>Réf. Facture</td><td>Client</td><td class="right">Montant TTC</td><td class="center">Date limite de règlement</td></tr>';
$sql_clients_list = "SELECT f.rowid, f.ref, f.total_ttc, f.date_lim_reglement, s.nom as societe_nom FROM ".MAIN_DB_PREFIX."facture as f LEFT JOIN ".MAIN_DB_PREFIX."societe as s ON f.fk_soc = s.rowid WHERE f.fk_statut = 1 AND f.date_lim_reglement >= '".$db->idate($date_start_month)."' AND f.date_lim_reglement <= '".$db->idate($date_end_month)."'";
$resql_clients_list = $db->query($sql_clients_list);
if ($resql_clients_list && $db->num_rows($resql_clients_list) > 0) {
    while ($obj = $db->fetch_object($resql_clients_list)) {
        $facture_client_static->id = $obj->rowid;
        $facture_client_static->ref = $obj->ref;
        echo '<tr class="oddeven"><td>'.$facture_client_static->getNomUrl(1).'</td><td>'.$obj->societe_nom.'</td><td class="right">'.price($obj->total_ttc).'</td><td class="center">'.dol_print_date($db->jdate($obj->date_lim_reglement), 'day').'</td></tr>';
    }
    echo '<tr class="liste_total"><td colspan="3" class="right"><b>Total attendu :</b></td><td class="right"><b>'.price($total_a_recevoir_ce_mois).'</b></td></tr>';
} else {
    echo '<tr><td colspan="4" class="opacitymedium">Aucune facture client en attente de paiement ce mois-ci.</td></tr>';
}
echo '</table>';

print '<br>';
print_barre_liste('Factures fournisseurs à payer ce mois-ci', 0, $_SERVER["PHP_SELF"]);
echo '<table class="noborder centpercent">';
echo '<tr class="liste_titre"><td>Réf. Fournisseur</td><td>Fournisseur</td><td class="right">Montant TTC</td><td class="center">Date limite de règlement</td></tr>';
$sql_fournisseurs_list = "SELECT f.rowid, f.ref_supplier, f.total_ttc, f.date_lim_reglement, s.nom as societe_nom FROM ".MAIN_DB_PREFIX."facture_fourn as f LEFT JOIN ".MAIN_DB_PREFIX."societe as s ON f.fk_soc = s.rowid WHERE f.fk_statut = 1 AND f.date_lim_reglement >= '".$db->idate($date_start_month)."' AND f.date_lim_reglement <= '".$db->idate($date_end_month)."'";
$resql_fournisseurs_list = $db->query($sql_fournisseurs_list);
if ($resql_fournisseurs_list && $db->num_rows($resql_fournisseurs_list) > 0) {
    while ($obj = $db->fetch_object($resql_fournisseurs_list)) {
        $facture_fourn_static->id = $obj->rowid;
        $facture_fourn_static->ref_supplier = $obj->ref_supplier;
        echo '<tr class="oddeven"><td>'.$facture_fourn_static->getNomUrl(1).'</td><td>'.$obj->societe_nom.'</td><td class="right">'.price($obj->total_ttc).'</td><td class="center">'.dol_print_date($db->jdate($obj->date_lim_reglement), 'day').'</td></tr>';
    }
    echo '<tr class="liste_total"><td colspan="3" class="right"><b>Total à payer :</b></td><td class="right"><b>'.price($total_a_payer_fourn_ce_mois).'</b></td></tr>';
} else {
    echo '<tr><td colspan="4" class="opacitymedium">Aucune facture fournisseur à payer ce mois-ci.</td></tr>';
}
echo '</table>';

print '<br>';
print_barre_liste('Charges et Dépenses Spéciales à régler', 0, $_SERVER["PHP_SELF"]);
echo '<table class="noborder centpercent">';
echo '<tr class="liste_titre"><td>Type</td><td>Libellé / Réf.</td><td class="center">Date Échéance</td><td class="right">Montant</td></tr>';
$has_charges = false;
if (!empty($conf->expensereport->enabled)) {
    $sql_ndf_list = "SELECT er.rowid, er.ref, er.total_ttc, er.date_approve FROM ".MAIN_DB_PREFIX."expensereport as er WHERE er.fk_statut = 5 AND er.paye = 0";
    $resql_ndf_list = $db->query($sql_ndf_list);
    if ($resql_ndf_list && $db->num_rows($resql_ndf_list) > 0) {
        $has_charges = true;
        while($obj = $db->fetch_object($resql_ndf_list)) {
            $expensereport_static->id = $obj->rowid;
            $expensereport_static->ref = $obj->ref;
            echo '<tr class="oddeven"><td>Note de Frais</td><td>'.$expensereport_static->getNomUrl(1).'</td><td class="center">Validée le '.dol_print_date($db->jdate($obj->date_approve), 'day').'</td><td class="right">'.price($obj->total_ttc).'</td></tr>';
        }
    }
}
if (!empty($conf->tax->enabled)) {
    $sql_charges_list = "SELECT cs.rowid, cs.libelle, cs.amount, cs.date_ech FROM ".MAIN_DB_PREFIX."chargesociales as cs WHERE cs.paye = 0 AND cs.date_ech >= '".$db->idate($date_start_month)."' AND cs.date_ech <= '".$db->idate($date_end_month)."'";
    $resql_charges_list = $db->query($sql_charges_list);
    if ($resql_charges_list && $db->num_rows($resql_charges_list) > 0) {
        $has_charges = true;
        while($obj = $db->fetch_object($resql_charges_list)) {
            $charge_static->id = $obj->rowid;
            $charge_static->ref = $obj->libelle;
            $charge_static->libelle = $obj->libelle;
            echo '<tr class="oddeven"><td>Charge Sociale/Fiscale</td><td>'.$charge_static->getNomUrl(1).'</td><td class="center">'.dol_print_date($db->jdate($obj->date_ech), 'day').'</td><td class="right">'.price($obj->amount).'</td></tr>';
        }
    }
}
if (!$has_charges) {
    echo '<tr><td colspan="4" class="opacitymedium">Aucune note de frais à rembourser ou charge spéciale due ce mois-ci.</td></tr>';
} else {
	echo '<tr class="liste_total"><td colspan="3" class="right"><b>Total Charges & Dépenses :</b></td><td class="right"><b>'.price($total_charges_prevu).'</b></td></tr>';
}
echo '</table>';

// ==============================================================================
// --- SECTION "ACTIVITÉ RÉALISÉE CE MOIS-CI" ---
// ==============================================================================
print '<br><br>';
print_barre_liste('Factures clients réglées ce mois-ci', 0, $_SERVER["PHP_SELF"]);
echo '<table class="noborder centpercent">';
echo '<tr class="liste_titre"><td>Réf. Facture</td><td>Client</td><td class="right">Montant Facture</td><td class="center">Date Dernier Paiement</td></tr>';
$sql_cli_payees = "SELECT f.rowid, f.ref, f.total_ttc, s.nom as societe_nom, MAX(p.datep) as date_paiement
FROM ".MAIN_DB_PREFIX."facture as f
JOIN ".MAIN_DB_PREFIX."societe as s ON f.fk_soc = s.rowid
JOIN ".MAIN_DB_PREFIX."paiement_facture as pf ON pf.fk_facture = f.rowid
JOIN ".MAIN_DB_PREFIX."paiement as p ON pf.fk_paiement = p.rowid
WHERE f.fk_statut = 2
AND (
    CASE
        WHEN p.datep IS NOT NULL AND p.datep > '1971-01-01' THEN p.datep
        ELSE f.date_valid
    END
) BETWEEN '".$db->idate($date_start_month)."' AND '".$db->idate($date_end_month)."'
GROUP BY f.rowid, f.ref, f.total_ttc, s.nom";
$resql_cli_payees = $db->query($sql_cli_payees);
if ($resql_cli_payees && $db->num_rows($resql_cli_payees) > 0) {
    $total_recu_clients = 0;
    while ($obj = $db->fetch_object($resql_cli_payees)) {
        $facture_client_static->id = $obj->rowid;
        $facture_client_static->ref = $obj->ref;
        $total_recu_clients += $obj->total_ttc;
        echo '<tr class="oddeven">';
        echo '<td>'.$facture_client_static->getNomUrl(1).'</td>';
        echo '<td>'.$obj->societe_nom.'</td>';
        echo '<td class="right">'.price($obj->total_ttc).'</td>';
        echo '<td class="center">'.dol_print_date($db->jdate($obj->date_paiement), 'day').'</td>';
        echo '</tr>';
    }
    echo '<tr class="liste_total"><td colspan="3" class="right"><b>Total des factures réglées :</b></td><td class="right"><b>'.price($total_recu_clients).'</b></td></tr>';
} else {
    echo '<tr><td colspan="4" class="opacitymedium">Aucune facture client réglée ce mois-ci.</td></tr>';
}
echo '</table>';

print '<br>';
print_barre_liste('Factures fournisseurs payées ce mois-ci', 0, $_SERVER["PHP_SELF"]);
echo '<table class="noborder centpercent">';
echo '<tr class="liste_titre"><td>Réf. Fournisseur</td><td>Fournisseur</td><td class="right">Montant Facture</td><td class="center">Date Dernier Paiement</td></tr>';
$sql_fourn_payees = "SELECT f.rowid, f.ref_supplier, f.total_ttc, s.nom as societe_nom, MAX(p.datep) as date_paiement
FROM ".MAIN_DB_PREFIX."facture_fourn as f
JOIN ".MAIN_DB_PREFIX."societe as s ON f.fk_soc = s.rowid
JOIN ".MAIN_DB_PREFIX."paiementfourn_facturefourn as pf ON pf.fk_facturefourn = f.rowid
JOIN ".MAIN_DB_PREFIX."paiementfourn as p ON pf.fk_paiementfourn = p.rowid
WHERE f.fk_statut = 2
AND p.datep BETWEEN '".$db->idate($date_start_month)."' AND '".$db->idate($date_end_month)."'
GROUP BY f.rowid, f.ref_supplier, f.total_ttc, s.nom";
$resql_fourn_payees = $db->query($sql_fourn_payees);
if ($resql_fourn_payees && $db->num_rows($resql_fourn_payees) > 0) {
    $total_paye_fournisseurs = 0;
    while ($obj = $db->fetch_object($resql_fourn_payees)) {
        $facture_fourn_static->id = $obj->rowid;
        $facture_fourn_static->ref_supplier = $obj->ref_supplier;
        $total_paye_fournisseurs += $obj->total_ttc;
        echo '<tr class="oddeven"><td>'.$facture_fourn_static->getNomUrl(1).'</td><td>'.$obj->societe_nom.'</td><td class="right">'.price($obj->total_ttc).'</td><td class="center">'.dol_print_date($db->jdate($obj->date_paiement), 'day').'</td></tr>';
    }
    echo '<tr class="liste_total"><td colspan="3" class="right"><b>Total des factures payées :</b></td><td class="right"><b>'.price($total_paye_fournisseurs).'</b></td></tr>';
} else {
    echo '<tr><td colspan="4" class="opacitymedium">Aucune facture fournisseur payée ce mois-ci.</td></tr>';
}
echo '</table>';

print '<br>';
print_barre_liste('Charges Sociales Réglées ce mois-ci', 0, $_SERVER["PHP_SELF"]);
echo '<table class="noborder centpercent">';
echo '<tr class="liste_titre"><td>Libellé</td><td class="center">Date de Paiement</td><td class="right">Montant Payé</td></tr>';
$sql_charges_payees = "SELECT cs.rowid, cs.libelle, cs.amount, cs.date_creation as date_paiement
                      FROM ".MAIN_DB_PREFIX."chargesociales as cs
                      WHERE cs.paye = 1
                      AND cs.date_creation >= '".$db->idate($date_start_month)."'
                      AND cs.date_creation <= '".$db->idate($date_end_month)."'";
$resql_charges_payees = $db->query($sql_charges_payees);
if ($resql_charges_payees && $db->num_rows($resql_charges_payees) > 0) {
    $total_charges_payees = 0;
    while ($obj = $db->fetch_object($resql_charges_payees)) {
        $charge_static->id = $obj->rowid;
        $charge_static->ref = $obj->libelle;
        $total_charges_payees += $obj->amount;
        echo '<tr class="oddeven">';
        echo '<td>'.$charge_static->getNomUrl(1).'</td>';
        echo '<td class="center">'.dol_print_date($db->jdate($obj->date_paiement), 'day').'</td>';
        echo '<td class="right">'.price($obj->amount).'</td>';
        echo '</tr>';
    }
    echo '<tr class="liste_total"><td colspan="2" class="right"><b>Total payé :</b></td><td class="right"><b>'.price($total_charges_payees).'</b></td></tr>';
} else {
    echo '<tr><td colspan="3" class="opacitymedium">Aucune charge sociale réglée ce mois-ci.</td></tr>';
}
echo '</table>';


// --- FIN DE LA PAGE ---
llxFooter();
$db->close();
?>
}
et si je veu comparer les valeur du mois actuel avec le meme mois de l'annee precedente ?