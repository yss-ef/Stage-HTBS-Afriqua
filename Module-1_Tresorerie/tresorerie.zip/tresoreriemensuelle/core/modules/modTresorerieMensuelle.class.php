<?php
include_once DOL_DOCUMENT_ROOT.'/core/modules/DolibarrModules.class.php';

class modTresorerieMensuelle extends DolibarrModules
{
    public $hooks = array();
    public $rights = array();
    public $menu = array();
    public $const = array();
    public $tabs = array();
    public $boxes = array();
    public $dictionaries = array();
    public $cronjobs = array();

    public function __construct($db)
    {
        global $conf, $langs;

        $this->db = $db;
        $this->numero = 500002;
        $this->rights_class = 'tresoreriemensuelle';
        $this->family = "financial";
        $this->name = preg_replace('/^mod/i', '', get_class($this));
        // MODIFIÉ : Description plus complète
        $this->description = "Tableau de bord de trésorerie avec une vue mensuelle et une synthèse annuelle des flux financiers.";
        $this->editor_name = 'Youssef Fellah';
        $this->editor_url  = 'https://github.com/yss-ef';
        $this->version = '2.0';
        $this->const_name = 'MAIN_MODULE_'.strtoupper($this->name);
        $this->picto = 'fa-chart-line'; // Icône principale du module

        // --- DÉFINITION DE LA NOUVELLE STRUCTURE DU MENU ---
        $r = 0;

        // 1. Entrée du menu principal (en haut)
        // Cette entrée sert de "parent" pour le menu de gauche.
        $this->menu[$r++] = array(
            'fk_menu' => '',
            'type' => 'top',
            'titre' => 'Trésorerie', // Titre plus court pour le menu du haut
            'mainmenu' => 'tresoreriemensuelle',
            'leftmenu' => 'tresoreriemensuelle',
            'url' => '/custom/tresoreriemensuelle/tresoreriemensuelleindex.php',
            'langs' => 'tresoreriemensuelle@tresoreriemensuelle',
            'position' => 50,
            'enabled' => 'isModEnabled("tresoreriemensuelle")',
            'perms' => '$user->rights->tresoreriemensuelle->read', // Droit de lecture
            'user' => 2
        );

        // 2. MODIFIÉ : Lien "Vue Mensuelle" dans le menu de gauche
        $this->menu[$r++] = array(
            'fk_menu' => 'fk_mainmenu=tresoreriemensuelle',
            'type' => 'left',
            'titre' => 'Vue Mensuelle',
            'prefix' => img_picto('', 'fa-tachometer-alt', 'class="paddingright pictofixedwidth valignmiddle"'),
            'url' => '/custom/tresoreriemensuelle/tresoreriemensuelleindex.php',
            'position' => 10,
            'enabled' => 'isModEnabled("tresoreriemensuelle")',
            'perms' => '$user->rights->tresoreriemensuelle->read',
            'user' => 2
        );

        // 3. NOUVEAU : Lien "Vue Annuelle" dans le menu de gauche
        $this->menu[$r++] = array(
            'fk_menu' => 'fk_mainmenu=tresoreriemensuelle',
            'type' => 'left',
            'titre' => 'Vue Annuelle',
            'prefix' => img_picto('', 'fa-calendar-alt', 'class="paddingright pictofixedwidth valignmiddle"'),
            'url' => '/custom/tresoreriemensuelle/vue_annuelle.php',
            'position' => 20,
            'enabled' => 'isModEnabled("tresoreriemensuelle")',
            'perms' => '$user->rights->tresoreriemensuelle->read',
            'user' => 2
        );

        // Définition des droits
        $this->rights = array();
        $this->rights[0][0] = $this->numero + 1;
        $this->rights[0][1] = 'Voir le tableau de bord de trésorerie';
        $this->rights[0][3] = 1;
        $this->rights[0][4] = 'read';

    }
    
    public function init($options = '') { $sql = array(); return $this->_init($sql, $options); }
    public function remove($options = '') { $sql = array(); return $this->_remove($sql, $options); }
}